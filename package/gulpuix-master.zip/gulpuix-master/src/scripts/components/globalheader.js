$(document).ready(function() {
    "use strict";
    
    console.log("js is Loaded");

});
